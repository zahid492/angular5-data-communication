import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-componentc',
  templateUrl: './componentc.component.html',
  styleUrls: ['./componentc.component.css']
})
export class ComponentcComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
