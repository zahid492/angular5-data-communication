import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-componentb',
  templateUrl: './componentb.component.html',
  styleUrls: ['./componentb.component.css']
})
export class ComponentbComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
