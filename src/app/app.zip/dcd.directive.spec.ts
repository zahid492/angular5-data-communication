import { DcdDirective } from './dcd.directive';

describe('DcdDirective', () => {
  it('should create an instance', () => {
    const directive = new DcdDirective();
    expect(directive).toBeTruthy();
  });
});
